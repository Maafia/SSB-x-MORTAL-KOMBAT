Just put your SMASH 64 ROM in this folder, 
then click and drag it into "windows-drag-here.bat"
It will then put the new SSB x Mortal Kombat rom in your OUTPUT FOLDER!

Have fun!

Oh also, current version uses a battle toads song I made, 
(Wookie Hole - Battletoads)
I still need to add Mortal Kombat music :P
enjoy <3